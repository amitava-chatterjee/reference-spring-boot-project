package com.company.reference;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReferenceSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
